package com.example.practicaut41_recyclerview_1.model

import android.icu.text.Transliterator.Position

data class MyData(val position: Int, val listaColores: List<ColorR>)
