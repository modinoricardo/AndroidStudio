package com.example.recyclerviewanimals.model

import android.icu.text.Transliterator.Position

data class MyData(val position:Int,  val animales: List<String>)
